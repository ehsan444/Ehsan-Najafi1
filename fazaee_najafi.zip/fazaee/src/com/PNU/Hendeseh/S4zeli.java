package com.PNU.Hendeseh;

public class S4zeli extends Shape {

    
    Line AB;
    Line BC;
    Line CD;
    Line DA;
    Zavieh alpha;
    Zavieh landa;

    public S4zeli(String name, Line AB, Line BC, Line CD, Line DA, Zavieh alpha, Zavieh landa) {
        super(name, demention.DOO);
        this.AB = AB;
        this.BC = BC;
        this.CD = CD;
        this.DA = DA;
        this.alpha = alpha;
        this.landa = landa;
    }

    public S4zeli(String name, Line AB, Line BC, Line CD, Line DA) {
        super(name, demention.DOO);
        this.AB = AB;
        this.BC = BC;
        this.CD = CD;
        this.DA = DA;
        this.alpha.andazeh = 90;
        this.landa.andazeh = 90;
    }


    // formula from : https://www.geeksforgeeks.org/maximum-area-quadrilateral/
    // alpha va landa 2 Zavieh mogabel ham and na 2 zavieh mojaver!
        public double masahat(Line a, Line b, Line c, Line d, Zavieh alpha, Zavieh landa) {
            double semiperimeter = (a.tool() + b.tool() + c.tool() + d.tool()) / 2;
            return Math.sqrt((semiperimeter - a.tool()) * (semiperimeter - b.tool()) * (semiperimeter - c.tool()) * (semiperimeter - d.tool()) -
                    (a.tool()*b.tool()*c.tool()*d.tool())*Math.pow((Math.cos((alpha.andazeh+landa.andazeh)/2)),2));

        }

    @Override
    public Point seghl() {
        Line AC = new Line(AB.mabda,BC.maghsad);//gotr
        Line BD = new Line(BC.mabda,CD.maghsad);//gotr
        mosallas T1 = new mosallas("T1",AB,BC,AC);
        mosallas T2 = new mosallas("T2",BC,CD,BD);
        mosallas T3 = new mosallas("T3",CD,DA,AC);
        mosallas T4 = new mosallas("T4",DA,AB,BD);
        Line L1 = new Line("L1",T1.seghl(),T3.seghl());
        Line L2 = new Line("L2",T2.seghl(),T4.seghl());
        Point seghl = new Point("seghl",Line.talaghi(L2,L1).x,Line.talaghi(L2,L1).y,Line.talaghi(L2,L1).z);
        return seghl;
    }

    @Override
    public double mohit() {
            return AB.tool()+BC.tool()+CD.tool()+DA.tool();
    }

    @Override
    public double masahat() {

        return masahat(AB,BC,CD,DA,alpha,landa);
        }

    @Override
    public double hajm() {
        return 0;
    }


}

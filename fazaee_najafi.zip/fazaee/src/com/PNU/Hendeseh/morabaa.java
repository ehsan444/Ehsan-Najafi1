package com.PNU.Hendeseh;

public class morabaa extends S4zeli {
    Line L1;
    public morabaa(String name, Line l1) {
        super(name, l1, l1, l1, l1);
        L1 = l1;
    }
}

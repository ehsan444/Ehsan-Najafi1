package com.PNU.Hendeseh;

public interface ThreeD_functions {
    double  ertefa();
    double masahat_janebi();
    double mohit_janebi();


}

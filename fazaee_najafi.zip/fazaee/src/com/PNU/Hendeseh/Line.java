package com.PNU.Hendeseh;

public class Line extends Shape {

    Point mabda;
    Point maghsad;
    boolean IsLine;

    public Line() {
        super("LINE", demention.YEK);
        IsLine = true;
    }

    public Line(String name, Point mabda, Point maghsad) {
        super(name, demention.YEK);
        this.mabda = mabda;
       this.maghsad = maghsad;

       if(NotEqaul()) IsLine=true;
       else {IsLine = false;
           System.out.println(name +"  yek pareh khat nist ");}
    }

    public Line(Point mabda, Point maghsad) {
        super("Line",demention.YEK);
        this.mabda = mabda;
        this.maghsad = maghsad;
         if(NotEqaul()) IsLine=true;
        else  IsLine = false;

    }

    public Point getMabda() {
        return mabda;
    }

    public Point getMaghsad() {
        return maghsad;
    }

    boolean NotEqaul()
    {
        if(mabda.getX() != maghsad.getX()) return true;
        if(mabda.getY() != maghsad.getY()) return true;
        if(mabda.getZ() != maghsad.getZ()) return true;
        return false;
    }

    public boolean isLine() {
        return IsLine;
    }

    @Override
    public Point seghl() {
        Point seghl = new Point();
        seghl.setX(    (mabda.getX()  + maghsad.getX()) /2   );
        seghl.setY(    (mabda.getY()  + maghsad.getY()) /2   );
        seghl.setZ(    (mabda.getZ()  + maghsad.getZ()) /2   );
        return seghl;
    }
    public  double tool() {

    return Math.sqrt( Math.pow(mabda.getX()-maghsad.getX(),2)+
            Math.pow(mabda.getY()-maghsad.getY(),2)+
            Math.pow(mabda.getZ()-maghsad.getZ(),2));
}


    public static  Point talaghi(Line AB, Line CD)
    {
        Point Talaghi = new Point();

        Point A = new Point();A= AB.getMabda();
        Point B = new Point(); B=AB.getMaghsad();
        Point C = new Point(); C=CD.getMabda();
        Point D =new Point();D= CD.getMaghsad();
double x1 = A.getX(),y1= A.getY(),z1=A.getZ(),
        x2 = B.getX(),y2= B.getY(),z2=B.getZ(),
        x3 = C.getX(),y3=C.getY(),z3=C.getZ(),
        x4 = D.getX(),y4= D.getY(),z4=D.getZ();

       Talaghi.setX(((x1*y2-y1*x2)*(x3-x4) - (x1-x2)*(x3*y4-y3*x4))/
               ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)));
       Talaghi.setY(((x1*y2-y1*x2)*(y3-y4)- (y1-y2)*(x3*y4-y3*x4))/
               ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)));
       Talaghi.setZ(((Talaghi.getY()-y1)*(z2-z1))/(y2-y1)+z1);
        return Talaghi;
    }
    @Override
    public double mohit() {
        return 0;
    }

    @Override
    public double masahat() {
        return 0;
    }

    @Override
    public double hajm() {
        return 0;
    }
}

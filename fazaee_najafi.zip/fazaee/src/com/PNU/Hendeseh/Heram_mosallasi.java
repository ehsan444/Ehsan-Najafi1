package com.PNU.Hendeseh;

public class Heram_mosallasi extends Shape implements ThreeD_functions{
    mosallas ghaede;
    Point raas;

    public Heram_mosallasi(String name, mosallas ghaede, Point raas) {
        super(name, demention.SEH);
        this.ghaede = ghaede;
        this.raas = raas;
    }

    public Heram_mosallasi(String name) {
        super(name, demention.SEH);
    }
    public Heram_mosallasi() {
        super("Heram_mosallasi", demention.SEH);
    }

    public mosallas getGhaede() {
        return ghaede;
    }

    public void setGhaede(mosallas ghaede) {
        this.ghaede = ghaede;
    }

    public Point getRaas() {
        return raas;
    }

    public void setRaas(Point raas) {
        this.raas = raas;
    }

    @Override
    public Point seghl() {
        Point seghl = new Point();
        Point Seghl_ghaede = ghaede.seghl();
        Line mianeh = new Line(Seghl_ghaede,raas);
        seghl = mianeh.seghl();
        return seghl;
    }

    @Override
    public double mohit() {
        return ghaede.mohit()+mohit_janebi();
    }

    @Override
    public double masahat() {
        return ghaede.masahat()+masahat_janebi();
    }

    @Override
    public double hajm() {
        return (ghaede.masahat() * ertefa())/3;
    }

    @Override
    public double ertefa() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CA.getMabda();
        Bordar z =  new Bordar();
        z = Safheh.hadi(a,b,c);
        double d = Safheh.distance(a,z);

        return Math.abs(z.X_V*raas.getX()+z.Y_V*raas.getY()+z.Z_V*raas.getZ()+d
        /(Math.sqrt(z.X_V*z.X_V+z.Y_V*z.Y_V+z.Z_V*z.Z_V)));
    }

    @Override
    public double masahat_janebi() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CA.getMabda();
        Line a_raas = new Line(a,raas);
        Line b_raas = new Line(b,raas);
        Line c_raas = new Line(c,raas);
        mosallas AB_raas = new mosallas("ABR",ghaede.AB,a_raas,b_raas);
        mosallas BC_raas = new mosallas("BCR",ghaede.BC,b_raas,c_raas);
        mosallas CA_raas = new mosallas("CAR",ghaede.CA,c_raas,a_raas);

        return AB_raas.masahat()+BC_raas.masahat()+CA_raas.masahat();
    }

    @Override
    public double mohit_janebi() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CA.getMabda();
        Line a_raas = new Line(a,raas);
        Line b_raas = new Line(b,raas);
        Line c_raas = new Line(c,raas);

        return a_raas.tool()+b_raas.tool()+c_raas.tool();
    }

}

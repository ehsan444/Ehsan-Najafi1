package com.PNU.Hendeseh;

public class mosallas extends Shape {
    Line AB;
    Line BC;
    Line CA;
    boolean IsMosallas;

    public mosallas() {
        super("ABC", demention.DOO);
        IsMosallas =true;
    }

    public mosallas(String name, Line AB, Line BC, Line CA) {
        super(name, demention.DOO);
        this.AB = AB;
        this.BC = BC;
        this.CA = CA;
        if(IsMosallas()) IsMosallas = true;
        else {
            IsMosallas = false;
            System.out.println(name + " yek mosallas nist");
        }

    }

    boolean Namosavi()
    {
        if(AB.tool()+BC.tool() > CA.tool() &&
                AB.tool()+CA.tool()>BC.tool()&&
                BC.tool()+CA.tool()>AB.tool())
            return  true;
        return false;
    }
    boolean IsMosallas()
    {
        if(AB.IsLine == false || BC.IsLine== false ||
                CA.IsLine==false) return false;
        Line AB_BC = new Line(AB.maghsad,BC.mabda);
        Line BC_CA = new Line(BC.maghsad,CA.mabda);
        Line CA_AB = new Line (CA.maghsad,AB.mabda);
        if(AB_BC.IsLine == false  && BC_CA.isLine() == false
                && CA_AB.IsLine == false )
            return true;

        return false;
    }

    @Override
    public Point seghl() {
        Point A = new Point ();
        A = AB.getMabda();
        Point BC_Segl= new Point();
        BC_Segl = BC.seghl();
        Line  Line1 = new Line(A,BC_Segl);
        Point B = new Point();
        B = AB.getMaghsad();
        Point AC_segl = new Point();
        AC_segl = CA.seghl();
        Line Line2 = new Line(B,AC_segl);

        return Line.talaghi(Line1,Line2);
    }

    @Override
    public double mohit() {
        if(IsMosallas==true)
           return AB.tool()+BC.tool()+CA.tool();
        return 0;
    }

    @Override
    public double masahat() {
        if(IsMosallas==true) {
            double s = mohit() / 2;

            return
                    Math.sqrt(s * (s - AB.tool()) * (s - BC.tool()) * (s - CA.tool()));
        }
        return 0;
    }

    @Override
    public double hajm() {
        return 0;
    }
}

package com.PNU.Hendeseh;

public class Zavieh {

    double andazeh;

    public Zavieh(double andazeh) {
        this.andazeh = andazeh;
        round();
    }

    public Zavieh() {
        this.andazeh=0;
    }

    public double radian()
    {
        return (andazeh*Math.PI)/180;
    }

    public  static double daraje(double rad){ return (rad*180/Math.PI);}

    void round()
    {
       this.andazeh %= 360;
    }
    public static double Zavieh_motaghate(Line A,Line B)
    {
        Bordar bA = Bordar.hadi_line(A);
        Bordar bB = Bordar.hadi_line(B);
        double zd =
                Math.abs((Bordar.Zarbe_dakheli(bA,bB) % (2*Math.PI))-Math.PI);

        return daraje(Math.abs(Math.acos(zd)));
    }
}


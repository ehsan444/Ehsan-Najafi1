package com.PNU.Hendeseh;

public class Point extends Shape{

    double x;
    double y;
    double z;

    public Point() {
        super("POINT", demention.SEFR);
    }

    public Point(String n,double x, double y, double z) {
        super(n, demention.SEFR);
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return z;
    }

    public void setZ(double z) {
        this.z = z;
    }
  public void print()
  {
      System.out.println("["+x+", "+y+", "+z+"]");
  }
    @Override
    public Point seghl() {
        return this;
    }

    @Override
    public double mohit() {
        return 0;
    }

    @Override
    public double masahat() {
        return 0;
    }

    @Override
    public double hajm() {
        return 0;
    }

}

package com.PNU.Hendeseh;

public class moostaiil extends S4zeli {
    Line TOOL;
    Line ARZ;

    public moostaiil(String name, Line tool, Line arz) {
        super(name, tool, arz, tool, arz);
        TOOL = tool;
        ARZ = arz;
    }
}

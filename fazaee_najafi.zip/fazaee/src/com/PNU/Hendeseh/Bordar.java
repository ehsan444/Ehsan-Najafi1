package com.PNU.Hendeseh;

public class Bordar {

    double X_V;
    double  Y_V;
    double Z_V;

    Point avalieh;

    public Bordar() {
    }

    public Bordar(double x_V, double y_V, double z_V,Point av) {
        X_V = x_V;
        Y_V = y_V;
        Z_V = z_V;
        avalieh = av;
    }
   public boolean check(Point P)
   {
     if((P.getX()-avalieh.getX())/X_V ==
             (P.getY()-avalieh.getY())/Y_V   &&

             (P.getX()-avalieh.getX())/X_V ==
                     (P.getZ()-avalieh.getZ())/Z_V )
        return true;
     return false;
   }
   public static Bordar hadi (Point  A, Point B)
   {
       Bordar  b = new Bordar();
       b.X_V = B.getX() - A.getX();
       b.Y_V = B.getY() - A.getY();
       b.Z_V = B.getZ() - A.getZ();
       return b;
   }
   public static Bordar hadi_line(Line A)
   {
       Point a = new Point();
       Point b = new Point();
       a = A.getMabda();
       b = A.getMaghsad();
       return hadi(a,b);
   }
   public static Bordar Zarbe_khareji(Bordar A, Bordar B)
   {
       Bordar z = new Bordar();
       z.X_V = A.Z_V*B.Y_V - A.Y_V*B.Z_V;
       z.Y_V = A.Z_V*B.X_V - A.X_V* B.Z_V;
       z.Z_V = A.X_V*B.Y_V - A.Y_V*B.X_V;
       return  z;
   }
   public static double Zarbe_dakheli(Bordar A,Bordar B)
   {
       return A.X_V*B.X_V+A.Y_V*B.Y_V+A.Z_V*B.Z_V;
   }
}

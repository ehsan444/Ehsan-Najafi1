 package com.PNU.Hendeseh;
enum demention {SEFR,YEK,DOO,SEH};
public abstract class Shape {

    String name;
    demention boad;

    public Shape(String name, demention boad) {
        this.name = name;
        this.boad = boad;
    }

    public abstract Point seghl();
    public abstract double mohit();
    public abstract double masahat();
    public abstract  double  hajm();
}

package com.PNU.Hendeseh;

public class Dayereh extends Shape{
    Point markaz;
    double shoa;

    public Dayereh(String name, Point markaz, double shoa) {
        super(name, demention.DOO);
        this.markaz = markaz;
        this.shoa = shoa;
    }

    public Dayereh() {
        super("Dayereh",demention.DOO);
    }

    @Override
    public Point seghl() {
        return markaz;
    }

    @Override
    public double mohit() {
    return shoa*2*Math.PI;
    }

    @Override
    public double masahat() {
        return Math.pow(shoa,2)*Math.PI;
    }

    @Override
    public double hajm() {
        return 0;
    }
}

package com.PNU.Hendeseh;

public class heram_4zeli extends Shape implements ThreeD_functions{
    S4zeli ghaede;
    Point raas;

    public heram_4zeli(String name, S4zeli ghaede, Point raas) {
        super(name, demention.SEH);
        this.ghaede = ghaede;
        this.raas = raas;
    }


    public heram_4zeli(String name) {
        super(name, demention.SEH);
    }
    public heram_4zeli() {
        super("Heram_mosallasi", demention.SEH);
    }

    public S4zeli getGhaede() {
        return ghaede;
    }



    public void setGhaede(S4zeli ghaede) {
        this.ghaede = ghaede;
    }

    public Point getRaas() {
        return raas;
    }

    public void setRaas(Point raas) {
        this.raas = raas;
    }


    @Override
    public Point seghl() {
        Point seghl = new Point();
        Point Seghl_ghaede = ghaede.seghl();
        Line mianeh = new Line(Seghl_ghaede,raas);
        seghl = mianeh.seghl();
        return seghl;
    }

    public heram_4zeli(String name, demention boad) {
        super(name, boad);
    }

    @Override
    public double mohit() {
        return ghaede.mohit()+mohit_janebi();
    }

    @Override
    public double masahat() {
        return ghaede.masahat()+masahat_janebi();
    }

    @Override
    public double hajm() {
        return (ghaede.masahat() * ertefa())/3;
    }

    @Override
    public double ertefa() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CD.getMabda();
        Bordar z =  new Bordar();
        z = Safheh.hadi(a,b,c);
        double d = Safheh.distance(a,z);

        return Math.abs(z.X_V*raas.getX()+z.Y_V*raas.getY()+z.Z_V*raas.getZ()+d
                /(Math.sqrt(z.X_V*z.X_V+z.Y_V*z.Y_V+z.Z_V*z.Z_V)));
    }


    @Override
    public double masahat_janebi() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CD.getMabda();
        Point d = new Point();
        d = ghaede.CD.getMaghsad();
        Line a_raas = new Line(a,raas);
        Line b_raas = new Line(b,raas);
        Line c_raas = new Line(c,raas);
        Line d_raas = new Line(d,raas);
        mosallas AB_raas = new mosallas("ABR",ghaede.AB,a_raas,b_raas);
        mosallas BC_raas = new mosallas("BCR",ghaede.BC,b_raas,c_raas);
        mosallas CA_raas = new mosallas("CDR",ghaede.CD,c_raas,a_raas);
        mosallas DA_raas = new mosallas("DAR",ghaede.DA,d_raas,a_raas);

        return AB_raas.masahat()+BC_raas.masahat()+CA_raas.masahat()+DA_raas.masahat();
    }

    @Override
    public double mohit_janebi() {
        Point a = new Point();
        a = ghaede.AB.getMabda();
        Point b =  new Point();
        b = ghaede.AB.getMaghsad();
        Point c = new Point();
        c = ghaede.CD.getMabda();
        Point d = new Point();
        d = ghaede.CD.getMaghsad();
        Line a_raas = new Line(a,raas);
        Line b_raas = new Line(b,raas);
        Line c_raas = new Line(c,raas);
        Line d_raas = new Line(d,raas);

        return a_raas.tool()+b_raas.tool()+c_raas.tool()+d_raas.tool();
    }
}

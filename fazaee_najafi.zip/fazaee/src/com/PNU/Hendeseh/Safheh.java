package com.PNU.Hendeseh;

public class Safheh {
    Bordar bordar;
    double distance;

    public Safheh(Bordar bordar, double d) {
        this.bordar = bordar;
        this.distance = d;
    }

    public Safheh() {
    }
    public  boolean check(Point p)
    {
       double d =  p.getX() * bordar.X_V + p.getY()*bordar.Y_V+
               p.getZ() * bordar.Z_V + distance;
       if(d==0) return true;
       return false;
    }
    public static Bordar  hadi(Point  A, Point B , Point C)
    {
        Bordar z = new Bordar();
        Bordar AB = new Bordar();
        AB =  Bordar.hadi(A,B);
        Bordar AC = new Bordar();
        AC = Bordar.hadi(A,C);
        z = Bordar.Zarbe_khareji(AB,AC);
        return  z;
    }
    public static double distance(Point A, Bordar hadi)
    {
        return -1*(hadi.X_V*A.getX()
                +hadi.Y_V*A.getY()+hadi.Z_V*A.getZ());
    }
    public static boolean Check_Point(Point a,Point b,Point c,Point p)
    {
        Bordar h = new Bordar();
        h = hadi(a,b,c);
        double d = distance(a,h);
        Safheh s = new Safheh(h,d);
        return     s.check(p); }

}

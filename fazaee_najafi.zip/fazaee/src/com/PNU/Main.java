//Ehsan Najafi


package com.PNU;
import com.PNU.Hendeseh.*;
public class Main {
    public static void main(String[] args) {

     Point A =  new Point("A",0,0,1);
     Point B =  new Point("B",0,1,0);
     Point C = new Point ("C",1,0,0);
     Line AB = new Line ("AB",A,B);
     Line BC =  new Line("BC",B,C);
     Line CA =  new Line ("CA",C,A);
     mosallas ABC = new mosallas("ABC",AB,BC,CA);
     Point ras = new Point("r",5,6,7) ;

        System.out.println("Zavieh B mosallas = "
                +Zavieh.Zavieh_motaghate(AB,BC));
if(Safheh.Check_Point(A,B,C,ras) == false)
{
   Heram_mosallasi hm = new Heram_mosallasi("ABCR",ABC,ras) ;
    System.out.println(hm.hajm());
}
    }
}
